import Layout from '../components/layout';

export default () => (
  <Layout>
    This is the media page. Find the Guess.js logo <a href="https://github.com/guess-js/media">here</a>.
  </Layout>
);

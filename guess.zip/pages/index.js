import React from 'react';
import Layout from '../components/layout';
import Sample from "../components/Sample"

import ProductList from "../components/productList";

export default class Index extends React.Component {
  render() {
    return (
      <Layout>
       {/* <Sample/> */}
       <ProductList/>
      </Layout>
    );
  }
}

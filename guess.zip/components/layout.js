import React, { Component } from "react";
// import Link from "next/link";
import styled from "styled-components";
//  import logo from "../guess.png";
import { ButtonContainer } from "./Button";

import { withRouter } from "next/router";
import { guess } from "guess-webpack/api";

import Link from "next/link";
import Head from "next/head";

const layout = ({ router, children, title = "🔮 Next.js + Guess.js" }) => {
  let predictions = [];
  if (typeof window !== "undefined") {
    predictions = Object.keys(guess()).sort((a, b) => a.length - b.length);
    predictions.forEach(p => router.prefetch(p));
  }

  return (
    <div>
      <Head>
        <title>{title}</title>
        <link
          href="https://fonts.googleapis.com/css?family=Roboto:300"
          rel="stylesheet"
        />

        <meta charSet="utf-8" />
        <meta name="viewport" content="initial-scale=1.0, width=device-width" />
        <link rel="icon" href="/static/favicon.ico" type="image/x-icon" />

        <link rel="stylesheet" href="/static/styles.css" />
      </Head>
      <header>
        <Nav className="navbar navbar-expand-sm  navbar-dark px-sm-5">
          {/* <Link href="/">
          
          <span className="guess-logo">
            <img src="/static/guess.png" alt="store" className="navbar-brand"/>
          </span>
        </Link>
      */}

          <Link href="/">
            <a>Home</a>
          </Link>

          <Link href="/signup" className="ml-auto">
            <ButtonContainer>
              <span className="mr-2">
                <i className="fas fa-cart-plus " />
              </span>
              Signup
            </ButtonContainer>
          </Link>
          <Link href="/login" className="ml-auto">
            <ButtonContainer>
              <span className="mr-2">
                <i className="fas fa-cart-plus " />
              </span>
              Login
            </ButtonContainer>
          </Link>
          <Link href="/cart" className="ml-auto">
            <ButtonContainer>
              <span className="mr-2">
                <i className="fas fa-cart-plus " />
              </span>
              Cart
            </ButtonContainer>
          </Link>
        </Nav>
      </header>
      <div className="content">{children}</div>
    </div>
  );
};

export default withRouter(layout);

const Nav = styled.nav`
color: red;
  background: var(--mainBlue);
  .nav-link {
    color: var(--mainWhite) !important;
    font-size:1.3rem;
    text-transform:capitalize;
  }
  @media (max-width: 576px) {
    .navbar-nav {
      flex-direction: row !important;
`;

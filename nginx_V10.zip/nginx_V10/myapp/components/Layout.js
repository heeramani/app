import Link from "next/link";
import Head from "next/head";

const linkStyle = {
  marginRight: 15
};

const Layout = () => (
  <div>
    <Link href="/">
      <a style={linkStyle}>Home</a>
    </Link>
    <Link href="/about">
      <a style={linkStyle}>About</a>
    </Link>
    <Link href="/cart">
      <a style={linkStyle}>Cart</a>
    </Link>
    <Link href="/contact">
      <a style={linkStyle}>Contact</a>
    </Link>
    <Link href="/login">
      <a style={linkStyle}>Login</a>
    </Link>
    <Link href="/signup">
      <a style={linkStyle}>Signup</a>
    </Link>
  </div>
);

export default Layout;

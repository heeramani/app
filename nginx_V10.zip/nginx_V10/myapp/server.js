// // const express = require("express");
// // const next = require("next");
// // const { join } = require("path");
// // const colors = require("colors/safe");
// // const cache = require("lru-cache"); // for using least-recently-used based caching
// // const port = parseInt(process.env.PORT, 10) || 4000;
// // const dev = process.env.NODE_ENV !== "production";
// // const app = next({ dev });
// // const handle = app.getRequestHandler();

// // app.prepare().then(() => {
// //   const server = express();

// //   // server.get("/", (req, res) => {
// //   //   console.log(colors.rainbow("home"));
// //   //   // res.send("oK");
// //   // });
// //   // server.get("/about", (req, res) => {
// //   //   console.log(colors.rainbow("about"));
// //   //   res.send("oK");
// //   // });
// //   // server.get("/contact", (req, res) => {
// //   //   console.log(colors.rainbow("contact"));
// //   //   res.send("oK");
// //   // });
// //   // server.get("/cart", (req, res) => {
// //   //   console.log(colors.rainbow("cart"));
// //   //   res.send("oK");
// //   // });
// //   // server.get("/login", (req, res) => {
// //   //   console.log(colors.rainbow("login"));
// //   //   res.send("oK");
// //   // });

// //   server.get("*", (req, res) => {
// //     if (req.url.includes("/sw")) {
// //       const filePath = join(__dirname, "static", "workbox", "sw.js");
// //       app.serveStatic(req, res, filePath);
// //     } else if (req.url.startsWith("static/workbox/")) {
// //       app.serveStatic(req, res, join(__dirname, req.url));
// //     } else {
// //       handle(req, res, req.url);
// //     }
// //   });

// //   server.get("*", (req, res) => {
// //     return handle(req, res);
// //   });

// //   server.listen(port, err => {
// //     if (err) throw err;
// //     console.log(`> Ready on http://localhost:${port}`);
// //   });
// // });

// // const fastify = require("fastify")({ logger: { level: "error" } });

// const Next = require("next");
// const fs = require("fs");
// const path = require("path");
// // const staticServe = require("fastify");
// const serveStatic = require("fastify-static");

// // import serveStatic from "fastify-static";

// const fastify = require("fastify")({
//   http2: true,
//   https: {
//     // allowHTTP1: true, // fallback support for HTTP1
//     key: fs.readFileSync(path.join(__dirname, "fastify.key")),
//     cert: fs.readFileSync(path.join(__dirname, "fastify.crt"))
//   },
//   logger: { level: "trace" },
//   trustProxy: "127.0.0.1,192.168.1.1/24"
// });
// const port = parseInt(process.env.PORT, 10) || 3000;
// const dev = process.env.NODE_ENV !== "production";
// const STATIC_DIR = path.join(__dirname, "static");

// fastify
//   .register(serveStatic, {
//     root: STATIC_DIR,
//     prefix: "/static/",
//     maxAge: "1y"
//   })
//   .register((fastify, opts, next) => {
//     const app = Next({ dev });

//     app
//       .prepare()
//       .then(() => {
//         if (dev) {
//           fastify.get("/_next/*", (req, reply) => {
//             return app.handleRequest(req.req, reply.res).then(() => {
//               reply.sent = true;
//             });
//           });
//         }
//         // fastify.on("error", err => console.error(err));

//         fastify.get("*", (req, reply) => {
//           return app.handleRequest(req.req, reply.res).then(() => {
//             reply.sent = true;
//           });
//         });

//         fastify.setNotFoundHandler((request, reply) => {
//           return app.render404(request.req, reply.res).then(() => {
//             reply.sent = true;
//           });
//         });

//         next();
//       })
//       .catch(err => next(err));
//   });

// fastify.listen(port, err => {
//   if (err) throw err;
//   console.log(`> Ready on http://localhost:${port}`);
// });

// // const fs = require("fs");
// // const path = require("path");
// // const fastify = require("fastify")({
// //   http2: true,
// //   https: {
// //     allowHTTP1: true, // fallback support for HTTP1
// //     key: fs.readFileSync(path.join(__dirname, "fastify.key")),
// //     cert: fs.readFileSync(path.join(__dirname, "fastify.crt"))
// //   }
// // });

// // // this route can be accessed through both protocols
// // fastify.get("/*", function(request, reply) {
// //   reply.code(200).send({ hello: "world" });
// // });

// // fastify.listen(3000);

// const express = require("express");
// const next = require("next");
// const { join } = require("path");
// const colors = require("colors/safe");
// const cache = require("lru-cache"); // for using least-recently-used based caching
// const port = parseInt(process.env.PORT, 10) || 4000;
// const dev = process.env.NODE_ENV !== "production";
// const app = next({ dev });
// const handle = app.getRequestHandler();

// app.prepare().then(() => {
//   const server = express();

//   // server.get("/", (req, res) => {
//   //   console.log(colors.rainbow("home"));
//   //   // res.send("oK");
//   // });
//   // server.get("/about", (req, res) => {
//   //   console.log(colors.rainbow("about"));
//   //   res.send("oK");
//   // });
//   // server.get("/contact", (req, res) => {
//   //   console.log(colors.rainbow("contact"));
//   //   res.send("oK");
//   // });
//   // server.get("/cart", (req, res) => {
//   //   console.log(colors.rainbow("cart"));
//   //   res.send("oK");
//   // });
//   // server.get("/login", (req, res) => {
//   //   console.log(colors.rainbow("login"));
//   //   res.send("oK");
//   // });

//   server.get("*", (req, res) => {
//     if (req.url.includes("/sw")) {
//       const filePath = join(__dirname, "static", "workbox", "sw.js");
//       app.serveStatic(req, res, filePath);
//     } else if (req.url.startsWith("static/workbox/")) {
//       app.serveStatic(req, res, join(__dirname, req.url));
//     } else {
//       handle(req, res, req.url);
//     }
//   });

//   server.get("*", (req, res) => {
//     return handle(req, res);
//   });

//   server.listen(port, err => {
//     if (err) throw err;
//     console.log(`> Ready on http://localhost:${port}`);
//   });
// });

// const fastify = require("fastify")({ logger: { level: "error" } });

const Next = require("next");
const fs = require("fs");
const path = require("path");
const serveStatic = require("fastify-static");
const fastify = require("fastify")({
  http2: true,
  https: {
    key: fs.readFileSync(path.join(__dirname, "fastify.key")),
    cert: fs.readFileSync(path.join(__dirname, "fastify.crt"))
  },
  logger: { level: "trace" },
  trustProxy: "127.0.0.1,192.168.1.1/24"
});
const port = parseInt(process.env.PORT, 10) || 3000;
const dev = process.env.NODE_ENV !== "production";
const STATIC_DIR = path.join(__dirname, "static");

fastify
  .register(serveStatic, {
    root: STATIC_DIR,
    prefix: "/static/",
    maxAge: "1y"
  })
  .register((fastify, opts, next) => {
    const app = Next({ dev });

    app
      .prepare()
      .then(() => {
        if (dev) {
          fastify.get("/_next/*", (req, reply) => {
            return app.handleRequest(req.req, reply.res).then(() => {
              reply.sent = true;
            });
          });
        }
        // fastify.on("error", err => console.error(err));

        fastify.get("*", (req, reply) => {
          return app.handleRequest(req.req, reply.res).then(() => {
            reply.sent = true;
          });
        });
        next();
      })
      .catch(err => next(err));
  });

fastify.listen(port, err => {
  if (err) throw err;
  console.log(`> Ready on http://localhost:${port}`);
});

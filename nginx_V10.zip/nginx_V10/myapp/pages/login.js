import Layout from "../components/Layout";
export default () => (
  <div>
    <Layout />
    <p>Login</p>
    <img src="/static/login/login-1.png" alt="my image" />;
    <img src="/static/login/login-2.png" alt="my image" />;
    <img src="/static/login/login-3.png" alt="my image" />;
    <img src="/static/login/login-4.png" alt="my image" />;
    <img src="/static/login/login-5.png" alt="my image" />;
  </div>
);

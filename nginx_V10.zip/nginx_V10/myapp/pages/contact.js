import Layout from "../components/Layout";
export default () => (
  <div>
    <Layout />
    <p>
      <a href="mailto:my@email.com">Contact us!</a>
    </p>
    <img src="/static/contact/contact-1.png" alt="my image" />;
    <img src="/static/contact/contact-2.png" alt="my image" />;
    <img src="/static/contact/contact-3.png" alt="my image" />;
    <img src="/static/contact/contact-4.png" alt="my image" />;
    <img src="/static/contact/contact-5.png" alt="my image" />;
  </div>
);

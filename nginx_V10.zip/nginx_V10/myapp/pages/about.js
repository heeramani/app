import Layout from "../components/Layout";
export default () => (
  <div>
    <Layout />
    <p>about</p>
    <img src="/static/about/about-1.png" alt="my image" />;
    <img src="/static/about/about-2.png" alt="my image" />;
    <img src="/static/about/about-3.png" alt="my image" />;
    <img src="/static/about/about-4.png" alt="my image" />;
    <img src="/static/about/about-5.png" alt="my image" />;
  </div>
);

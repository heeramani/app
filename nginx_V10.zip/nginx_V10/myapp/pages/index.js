import Link from "next/link";
import Layout from "../components/Layout";

export default class extends React.PureComponent {
  componentDidMount() {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker
        .register("/sw.js")
        .then(() => console.log("service worker registered."))
        .catch(err => console.dir(err));
    }
  }
  render() {
    return (
      <div>
        <Layout />
        <p>Hello World!</p>
        <img src="/static/index/index-1.png" alt="my image" />;
        <img src="/static/index/index-2.png" alt="my image" />;
        <img src="/static/index/index-3.png" alt="my image" />;
        <img src="/static/index/index-4.png" alt="my image" />;
        <img src="/static/index/index-5.png" alt="my image" />;
      </div>
    );
  }
}

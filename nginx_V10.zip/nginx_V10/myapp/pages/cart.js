import Layout from "../components/Layout";
import Router from "next/router";
export default () => (
  <div>
    <Layout />
    <p>Cart</p>
    {/* <p>This path({Router.prefetch("/about")}) should not be rendered via SSR</p> */}
    <img src="/static/cart/cart-1.png" alt="my image" />;
    <img src="/static/cart/cart-2.png" alt="my image" />;
    <img src="/static/cart/cart-3.png" alt="my image" />;
    <img src="/static/cart/cart-4.png" alt="my image" />;
    <img src="/static/cart/cart-5.png" alt="my image" />;
  </div>
);

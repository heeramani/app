import Layout from "../components/Layout";
export default () => (
  <div>
    <Layout />
    <p>Sign up</p>
    <img src="/static/signup/signup-1.png" alt="my image" />;
    <img src="/static/signup/signup-2.png" alt="my image" />;
    <img src="/static/signup/signup-3.png" alt="my image" />;
    <img src="/static/signup/signup-4.png" alt="my image" />;
    <img src="/static/signup/signup-5.png" alt="my image" />;
  </div>
);
